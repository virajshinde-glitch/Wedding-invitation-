WEDDING INVITATION WEBSITE

Files:
- index.html: invitation content and sections
- style.css: responsive design and styling
- script.js: opening button and WhatsApp RSVP

HOW TO CUSTOMIZE
1. Open index.html and replace the sample couple names, date, venue, family names and event times.
2. Replace the Google Maps URL with your venue's map link.
3. Open script.js and replace 91XXXXXXXXXX with the WhatsApp number that should receive RSVPs.
4. Open index.html in a browser to preview.

The website uses Google Fonts, so an internet connection is needed for those fonts.
The RSVP form sends a pre-filled WhatsApp message; it does not store responses in a database.
