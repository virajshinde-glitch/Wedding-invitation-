// Customize this with your WhatsApp number, including country code (India: 91).
const WHATSAPP_NUMBER = "91XXXXXXXXXX";

document.getElementById("exploreBtn").addEventListener("click", () => {
  document.getElementById("invitation").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("rsvpForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("guestName").value.trim();
  const guests = document.getElementById("guestCount").value;
  const attendance = document.getElementById("attendance").value;
  const message = `Wedding RSVP%0AName: ${encodeURIComponent(name)}%0AGuests: ${guests}%0AResponse: ${encodeURIComponent(attendance)}`;
  if (WHATSAPP_NUMBER === "91XXXXXXXXXX") {
    alert("Please add your WhatsApp number in script.js before using the RSVP button.");
    return;
  }
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank");
});
